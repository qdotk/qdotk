#pragma once

#include "BuildingSMActor.h"

class ABuildingTrap : public ABuildingSMActor
{
public:

};