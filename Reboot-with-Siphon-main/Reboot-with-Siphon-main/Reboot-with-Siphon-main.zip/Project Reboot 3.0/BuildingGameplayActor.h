#pragma once

#include "BuildingActor.h"

class ABuildingGameplayActor : public ABuildingActor
{
public:
};