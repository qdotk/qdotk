#pragma once

#include "BuildingActor.h"

class ABuildingRift : public ABuildingActor
{
public:
};